﻿[CmdletBinding()]
param(
    [string]$CodexHome,
    [string]$SourcePrompt,
    [string]$AgentsSource,
    [switch]$Uninstall,
    [switch]$Silent
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$Utf8 = New-Object System.Text.UTF8Encoding($false)

function Read-Utf8([string]$Path) {
    return [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
}
function Write-Utf8NoBom([string]$Path, [string]$Text) {
    [System.IO.File]::WriteAllText($Path, $Text, $Utf8)
}
function Get-ConfigValueLine([string]$Text) {
    $match = [regex]::Match($Text, '(?m)^\s*model_instructions_file\s*=\s*.*$')
    if ($match.Success) { return $match.Value }
    return $null
}

if ([string]::IsNullOrWhiteSpace($CodexHome)) {
    if ($env:CODEX_HOME) { $CodexHome = $env:CODEX_HOME }
    else { $CodexHome = Join-Path $HOME '.codex' }
}
$CodexHome = [System.IO.Path]::GetFullPath($CodexHome)
$configPath = Join-Path $CodexHome 'config.toml'
$managedDir = Join-Path $CodexHome 'managed-prompts'
$statePath = Join-Path $managedDir 'install-state.json'
$agentsTarget = Join-Path $CodexHome 'AGENTS.md'
$agentsBackup = Join-Path $managedDir 'AGENTS.md.orig'
$taskName = 'FJCodexPromptInject'
$startupCmd = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup\CodexPromptInject.cmd'

if ([string]::IsNullOrWhiteSpace($SourcePrompt)) {
    $SourcePrompt = Join-Path $PSScriptRoot '富江-破甲词-v8-英文.md'
}
if ([string]::IsNullOrWhiteSpace($AgentsSource)) {
    $AgentsSource = Join-Path $PSScriptRoot 'AGENTS.md'
}

if ($Uninstall) {
    $state = $null
    if (Test-Path -LiteralPath $statePath) { $state = Read-Utf8 $statePath | ConvertFrom-Json }

    if (Test-Path -LiteralPath $configPath) {
        $current = Read-Utf8 $configPath
        $pattern = '(?m)^\s*model_instructions_file\s*=\s*.*(?:\r?\n|$)'
        if ($state -and $state.hadLine -and ([string]$state.previousLine -notmatch 'managed-prompts')) {
            $repl = ([string]$state.previousLine + [Environment]::NewLine)
            $current = [regex]::Replace($current, $pattern, { param($m) $repl }, 1)
        } else {
            $current = [regex]::Replace($current, $pattern, '', 1)
        }
        Write-Utf8NoBom $configPath ($current.TrimEnd() + [Environment]::NewLine)
    }

    if ($state -and $state.agentsExisted -and (Test-Path -LiteralPath $agentsBackup)) {
        Copy-Item -LiteralPath $agentsBackup -Destination $agentsTarget -Force
    } else {
        Remove-Item -LiteralPath $agentsTarget -Force -ErrorAction SilentlyContinue
    }

    Get-ChildItem -LiteralPath $managedDir -Filter '*.md' -File -ErrorAction SilentlyContinue |
        Remove-Item -Force -ErrorAction SilentlyContinue

    if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    }
    Remove-Item -LiteralPath $startupCmd -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $agentsBackup -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $statePath -Force -ErrorAction SilentlyContinue
    if (-not (Get-ChildItem -LiteralPath $managedDir -Force -ErrorAction SilentlyContinue | Select-Object -First 1)) {
        Remove-Item -LiteralPath $managedDir -Force -ErrorAction SilentlyContinue
    }
    Write-Host "Uninstalled prompt from $CodexHome"
    exit 0
}

if (-not (Test-Path -LiteralPath $SourcePrompt -PathType Leaf)) {
    throw "Prompt file not found: $SourcePrompt"
}
New-Item -ItemType Directory -Force -Path $CodexHome, $managedDir | Out-Null
$configExisted = Test-Path -LiteralPath $configPath
$configText = if ($configExisted) { Read-Utf8 $configPath } else { '' }
$previousLine = Get-ConfigValueLine $configText

$targetPrompt = Join-Path $managedDir (Split-Path -Leaf $SourcePrompt)
Copy-Item -LiteralPath $SourcePrompt -Destination $targetPrompt -Force

$agentsExisted = Test-Path -LiteralPath $agentsTarget
if ($agentsExisted) {
    Copy-Item -LiteralPath $agentsTarget -Destination $agentsBackup -Force
}
if (Test-Path -LiteralPath $AgentsSource -PathType Leaf) {
    Copy-Item -LiteralPath $AgentsSource -Destination $agentsTarget -Force
}

$configPromptPath = $targetPrompt.Replace('\', '/')
$newLine = 'model_instructions_file = "' + $configPromptPath.Replace('"', '\"') + '"'
$linePattern = '(?m)^\s*model_instructions_file\s*=\s*.*$'
if ([regex]::IsMatch($configText, $linePattern)) {
    $configText = [regex]::Replace($configText, $linePattern, $newLine, 1)
} else {
    $configText = $newLine + [Environment]::NewLine + $configText
}
Write-Utf8NoBom $configPath ($configText.TrimEnd() + [Environment]::NewLine)

$taskOk = $false
try {
    if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    }
    $action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $PSCommandPath + '" -Silent')
    $trigger = New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"
    $principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Force | Out-Null
    $taskOk = $true
} catch {
    try {
        $cmdText = '@echo off' + [Environment]::NewLine + 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $PSCommandPath + '" -Silent'
        [System.IO.File]::WriteAllText($startupCmd, $cmdText, $Utf8)
        $taskOk = $true
    } catch { $taskOk = $false }
}

$state = [ordered]@{
    installedAt   = (Get-Date).ToString('o')
    configPath    = $configPath
    targetPrompt  = $targetPrompt
    agentsTarget  = $agentsTarget
    configExisted = $configExisted
    hadLine       = ($null -ne $previousLine)
    previousLine  = $previousLine
    agentsExisted = $agentsExisted
    autostart     = $taskOk
}
Write-Utf8NoBom $statePath (($state | ConvertTo-Json -Depth 3) + [Environment]::NewLine)

Write-Host "Installed prompt: $targetPrompt"
Write-Host "Injected agent:   $agentsTarget"
Write-Host "Updated config:   $configPath"
Write-Host "Autostart:        $taskOk"

if (-not $Silent) {
    $uiScript = Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.py' -File |
        Where-Object {
            [System.IO.File]::ReadAllText($_.FullName, [System.Text.Encoding]::UTF8) -match 'FloatWindow|Floating Window'
        } |
        Sort-Object Name |
        Select-Object -First 1 -ExpandProperty FullName
    if (-not $uiScript) {
        $uiScript = Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.py' -File |
            Sort-Object Name |
            Select-Object -First 1 -ExpandProperty FullName
    }
    if ($uiScript) {
        try {
            Start-Process -FilePath 'pythonw.exe' -ArgumentList @('"' + $uiScript + '"') -WindowStyle Hidden
        } catch {
            Start-Process -FilePath 'python' -ArgumentList @('"' + $uiScript + '"') -WindowStyle Hidden
        }
        Write-Host "Launched floating window: $uiScript"
    }
}
