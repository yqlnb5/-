#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iOS 风格 · 科技感悬浮窗 (Floating Window)
==========================================
特性:
  - 无边框 / 置顶 / 半透明 / 可拖拽
  - 毛玻璃质感 + 霓虹渐变描边 + 科技点阵 / 扫描线动画
  - 全屏模式: 任意分辨率下铺满整个屏幕, 圆角自动归零
  - 缩小/放大切换 (绿点 + 底部按钮), 平滑几何动画
  - 红=退出, 黄=最小化到托盘
  - 内容区当前为占位空状态, 后续按需填充

用法:
    python float_window.py              # 正常启动 (默认全屏)
    python float_window.py --windowed   # 以小悬浮窗启动
    python float_window.py --selftest   # 离屏自检并输出 preview*.png
    python float_window.py --smoke      # 真机冒烟测试 (1.5s 自动退出)
"""

import os
import sys
import subprocess

from PySide6.QtCore import (
    Qt, QPointF, QRectF, QRect, QTimer, QEasingCurve, QVariantAnimation, Signal,
    QProcess
)
from PySide6.QtGui import (
    QColor, QPainter, QBrush, QLinearGradient, QRadialGradient,
    QPen, QPainterPath, QIcon, QPixmap, QImage, QAction
)
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QSystemTrayIcon, QMenu, QGraphicsOpacityEffect, QScrollArea, QFrame,
    QSizePolicy
)

# ---------------------------------------------------------------- 配色
C_ACCENT_A = QColor(88, 210, 255)     # 青
C_ACCENT_B = QColor(130, 120, 255)    # 紫
C_ACCENT_C = QColor(255, 105, 205)    # 粉

FONT_UI = "Microsoft YaHei UI"

ACTIVATION_LINE = "已激活👽 QQ群1017552220     TG频道@FJNB99"
DISCLAIMER_TITLE = "免责声明"
AGREE_TEXT = "我同意 并接受所有条约"
DISCLAIMER_TEXT = (
    "本提示词、文档、代码及相关资料（下称“本内容”）仅供合法的教育学习、授权安全测试、技术研究与知识分享之用。\n\n"
    "1. 本内容仅面向具备完全民事行为能力的成年人。使用者须确保其获取、使用本内容的行为完全遵守所在国家/地区法律法规及第三方平台协议。\n"
    "2. 严禁将本内容用于任何违法或侵权活动，包括但不限于：制作外挂、网络入侵与 DDoS 攻击、传播恶意软件、伪造证件、诈骗、洗钱、走私、涉及枪械/爆炸物/毒品及危害人身安全的行为、诱导 AI 绕过安全机制实施违法、以及其他侵犯他人合法权益的行为。\n"
    "3. 使用者将本内容用于非法用途，属其个人独立行为，与提供方无关；由此产生的一切法律后果、经济责任及第三方索赔，均由使用者自行承担。\n"
    "4. 提供方不对使用者的任何行为承担任何直接或间接责任，不参与、不协助、不鼓励、不默许任何违法行为。\n"
    "5. 使用、复制、传播本内容即视为已阅读并同意本声明全部条款；不同意请立即停止使用并删除所有副本。\n\n"
    "提供方保留随时更新本声明的权利，更新后自发布之日起生效。"
)

TUTORIAL_TITLE = "使用教程"
TUTORIAL_TEXT = (
    "使用教程 不看死妈\n\n"
    "flash 适合那种中端模型 比如 v4 flash\n"
    "codex 顶级全破 就是 v4 pro 和 gpt5.6 用的了 那种顶尖模型\n\n"
    "执行完了 输入激活词「富江」 显示“已激活”就是可以了\n\n"
    "如果遇到不行的情况 重新开对话 重新发就行 有时候会概率拒绝的 正常\n"
    "一般执行一次之后第一次发是会拒绝 重新开个对话就可以了\n\n"
    "如果一直不行 要么是和谐了 要么是中转站惨水 因为安全对齐不一样 给你惨了傻子模型\n\n"
    "每次重启电脑记得重新执行 重启自动复原的\n\n"
    "永久免费       TG频道@FJNB99\n\n"
    "点空白处即可退出"
)


# ---------------------------------------------------------------- 交通灯按钮
class TrafficLight(QWidget):
    """macOS 风格红黄绿圆点, 悬停时显示符号"""
    clicked = Signal()

    def __init__(self, color, glyph=None, parent=None):
        super().__init__(parent)
        self._color = QColor(color)
        self._glyph = glyph
        self._hover = False
        self.setFixedSize(13, 13)
        self.setCursor(Qt.PointingHandCursor)

    def enterEvent(self, e):
        self._hover = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hover = False
        self.update()
        super().leaveEvent(e)

    def mouseReleaseEvent(self, e):
        if self.rect().contains(e.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        p.setPen(Qt.NoPen)
        p.setBrush(self._color)
        p.drawEllipse(r)

        hl = QRadialGradient(r.center() - QPointF(2, 2), r.width() * 0.8)
        hl.setColorAt(0.0, QColor(255, 255, 255, 80))
        hl.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.setBrush(hl)
        p.drawEllipse(r)

        if self._hover and self._glyph:
            pen = QPen(QColor(0, 0, 0, 150), 1.3)
            pen.setCapStyle(Qt.RoundCap)
            p.setPen(pen)
            cx, cy = r.center().x(), r.center().y()
            if self._glyph == "x":
                d = 3.0
                p.drawLine(QPointF(cx - d, cy - d), QPointF(cx + d, cy + d))
                p.drawLine(QPointF(cx - d, cy + d), QPointF(cx + d, cy - d))
            elif self._glyph == "-":
                p.drawLine(QPointF(cx - 3.2, cy), QPointF(cx + 3.2, cy))
            elif self._glyph == "+":
                p.drawLine(QPointF(cx - 3.2, cy), QPointF(cx + 3.2, cy))
                p.drawLine(QPointF(cx, cy - 3.2), QPointF(cx, cy + 3.2))


# ---------------------------------------------------------------- 标题栏
class TitleBar(QWidget):
    """顶部栏: 交通灯 + 标题 + 拖拽"""
    def __init__(self, window):
        super().__init__(window)
        self._win = window
        self.setFixedHeight(38)
        self.setAttribute(Qt.WA_TranslucentBackground)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(2, 0, 2, 0)
        lay.setSpacing(8)

        self.btn_close = TrafficLight("#ff5f57", "x", self)
        self.btn_min = TrafficLight("#febc2e", "-", self)
        self.btn_zoom = TrafficLight("#28c840", "+", self)

        self.btn_close.clicked.connect(window.quit)
        self.btn_min.clicked.connect(window.hide_to_tray)
        self.btn_zoom.clicked.connect(window.toggle_fullscreen)

        lay.addWidget(self.btn_close)
        lay.addWidget(self.btn_min)
        lay.addWidget(self.btn_zoom)

        self.title = QLabel("悬浮窗", self)
        self.title.setStyleSheet(
            "color:#eef2ff; font-family:'%s'; font-size:17px; font-weight:600;" % FONT_UI)
        lay.addSpacing(6)
        lay.addWidget(self.title)
        lay.addStretch(1)

        self.badge = QLabel("NEON GLASS · v0.2", self)
        self.badge.setStyleSheet(
            "color:rgba(150,160,190,170); font-family:'%s'; font-size:13px;" % FONT_UI)
        lay.addWidget(self.badge)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and not self._win._fullscreen:
            self._win._drag_offset = e.globalPosition().toPoint() - self._win.frameGeometry().topLeft()
            e.accept()

    def mouseMoveEvent(self, e):
        if self._win._drag_offset is not None and (e.buttons() & Qt.LeftButton):
            self._win.move_clamped(e.globalPosition().toPoint() - self._win._drag_offset)
            e.accept()

    def mouseReleaseEvent(self, e):
        self._win._drag_offset = None
        super().mouseReleaseEvent(e)


# ---------------------------------------------------------------- 功能按钮区
class ContentArea(QWidget):
    """两个模型安装按钮 + 状态反馈"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setMinimumHeight(160)

        h = QHBoxLayout(self)
        h.setContentsMargins(0, 0, 0, 0)

        self.inner = QWidget(self)
        self.inner.setAttribute(Qt.WA_TranslucentBackground)
        self.inner.setMaximumWidth(520)
        self.inner.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        lay = QVBoxLayout(self.inner)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(14)

        lay.addStretch(1)

        self.btn_tutorial = QPushButton("使用教程（不会必看）", self.inner)
        self.btn_tutorial.setCursor(Qt.PointingHandCursor)
        self.btn_tutorial.setFixedHeight(60)
        self.btn_tutorial.setMinimumWidth(280)
        self.btn_tutorial.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.btn_tutorial.setStyleSheet(
            "QPushButton{color:#1a0d00;"
            " background:qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #ffd76a, stop:1 #ff9f43);"
            " border:none; border-radius:16px;"
            " font-family:'%s'; font-size:17px; font-weight:700;}"
            "QPushButton:hover{background:qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #ffe08a, stop:1 #ffb25e);}"
            "QPushButton:pressed{background:qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #e8b84d, stop:1 #e08428);}"
            "QPushButton:disabled{background:rgba(90,100,130,60); color:rgba(200,210,230,120);}" % FONT_UI)
        self.btn_tutorial.clicked.connect(self._open_tutorial)
        lay.addWidget(self.btn_tutorial)

        hint = QLabel("选择要安装的模型", self.inner)
        hint.setAlignment(Qt.AlignCenter)
        hint.setStyleSheet(
            "color:rgba(150,160,190,190); font-family:'%s'; font-size:13px;" % FONT_UI)
        lay.addWidget(hint)

        self.btn_codex = self._make_button(
            "codex顶尖模型破甲", "#58d2ff", "#8278ff", "#7fddff", "#a293ff", "#3fb8e0", "#6659e0")
        self.btn_codex.clicked.connect(lambda: self._run("富江-变体B-v3-英文.md"))
        lay.addWidget(self.btn_codex)

        self.btn_flash = self._make_button(
            "flash模型专用破解", "#8278ff", "#ff69cd", "#a293ff", "#ff8bd6", "#6659e0", "#e04ba8")
        self.btn_flash.clicked.connect(lambda: self._run("富江-flash-v2.md"))
        lay.addWidget(self.btn_flash)

        self.btn_restart = QPushButton("重启 Codex", self.inner)
        self.btn_restart.setCursor(Qt.PointingHandCursor)
        self.btn_restart.setFixedHeight(44)
        self.btn_restart.setMinimumWidth(280)
        self.btn_restart.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.btn_restart.setStyleSheet(
            "QPushButton{color:#7fd8ff; background:rgba(88,190,255,12);"
            " border:1px solid rgba(88,190,255,60); border-radius:14px;"
            " font-family:'%s'; font-size:13px; font-weight:600;}"
            "QPushButton:hover{background:rgba(88,190,255,28); border-color:rgba(88,190,255,130);}"
            "QPushButton:pressed{background:rgba(88,190,255,50);}"
            "QPushButton:disabled{background:rgba(90,100,130,40); color:rgba(200,210,230,120);}" % FONT_UI)
        self.btn_restart.clicked.connect(self._restart)
        lay.addWidget(self.btn_restart)

        self.status = QLabel("就绪", self)
        self.status.setAlignment(Qt.AlignCenter)
        self.status.setStyleSheet(
            "color:rgba(150,160,190,170); font-family:'%s'; font-size:12px;" % FONT_UI)
        lay.addWidget(self.status)

        lay.addStretch(1)

        h.addWidget(self.inner, 1)

    def _make_button(self, text, g1, g2, h1, h2, p1, p2):
        btn = QPushButton(text, self.inner)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setFixedHeight(56)
        btn.setMinimumWidth(280)
        btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        btn.setStyleSheet(
            "QPushButton{color:#041018;"
            " background:qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 %s, stop:1 %s);"
            " border:none; border-radius:16px;"
            " font-family:'%s'; font-size:16px; font-weight:700;}"
            "QPushButton:hover{background:qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 %s, stop:1 %s);}"
            "QPushButton:pressed{background:qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 %s, stop:1 %s);}"
            "QPushButton:disabled{background:rgba(90,100,130,60); color:rgba(200,210,230,120);}"
            % (g1, g2, FONT_UI, h1, h2, p1, p2))
        return btn

    def _run(self, prompt):
        win = self.window()
        fn = getattr(win, "run_install", None)
        if fn:
            fn(prompt)

    def _restart(self):
        win = self.window()
        fn = getattr(win, "restart_codex", None)
        if fn:
            fn()

    def _open_tutorial(self):
        win = self.window()
        fn = getattr(win, "show_tutorial", None)
        if fn:
            fn()


# ---------------------------------------------------------------- 玻璃面板
class GlassPanel(QWidget):
    """在无边框透明窗口内绘制毛玻璃 + 动画背景"""
    def __init__(self, window):
        super().__init__(window)
        self._win = window
        self.setAttribute(Qt.WA_TranslucentBackground)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 12, 16, 16)
        lay.setSpacing(8)

        self.title_bar = TitleBar(window)
        lay.addWidget(self.title_bar)

        self.status = QLabel("● 已就绪", self)
        self.status.setStyleSheet(
            "color:#5fd0ff; font-family:'%s'; font-size:13px;" % FONT_UI)
        lay.addWidget(self.status)

        self.body = ContentArea(self)
        lay.addWidget(self.body, 1)

        self.footer_bar = QWidget(self)
        self.footer_bar.setAttribute(Qt.WA_TranslucentBackground)
        fl = QHBoxLayout(self.footer_bar)
        fl.setContentsMargins(0, 0, 0, 0)
        fl.setSpacing(10)

        self.footer = QLabel("拖拽顶部移动 · 黄点最小化 · 绿点放大缩小", self.footer_bar)
        self.footer.setStyleSheet(
            "color:rgba(150,160,190,130); font-family:'%s'; font-size:12px;" % FONT_UI)
        fl.addWidget(self.footer)
        fl.addStretch(1)

        self.btn_full = QPushButton("放大", self.footer_bar)
        self.btn_full.setCursor(Qt.PointingHandCursor)
        self.btn_full.setFixedHeight(32)
        self.btn_full.setStyleSheet(
            "QPushButton{color:#7fd8ff; background:rgba(88,190,255,22);"
            " border:1px solid rgba(88,190,255,70); border-radius:10px;"
            " padding:0 16px; font-family:'%s'; font-size:13px; font-weight:600;}"
            "QPushButton:hover{background:rgba(88,190,255,55); border-color:rgba(88,190,255,150);}"
            "QPushButton:pressed{background:rgba(88,190,255,90);}" % FONT_UI)
        self.btn_full.clicked.connect(window.toggle_fullscreen)
        fl.addWidget(self.btn_full)

        self.btn_exit = QPushButton("退出", self.footer_bar)
        self.btn_exit.setCursor(Qt.PointingHandCursor)
        self.btn_exit.setFixedHeight(32)
        self.btn_exit.setStyleSheet(
            "QPushButton{color:#ff8a90; background:rgba(255,95,87,26);"
            " border:1px solid rgba(255,95,87,80); border-radius:10px;"
            " padding:0 18px; font-family:'%s'; font-size:13px; font-weight:600;}"
            "QPushButton:hover{background:rgba(255,95,87,60); border-color:rgba(255,95,87,160);}"
            "QPushButton:pressed{background:rgba(255,95,87,95);}" % FONT_UI)
        self.btn_exit.clicked.connect(window.quit)
        fl.addWidget(self.btn_exit)

        lay.addWidget(self.footer_bar)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)

        rect = QRectF(self.rect())
        radius = float(getattr(self._win, "_corner_radius", 22.0))
        glass = QPainterPath()
        glass.addRoundedRect(rect, radius, radius)

        # 毛玻璃底色
        fill = QLinearGradient(rect.topLeft(), rect.bottomLeft())
        fill.setColorAt(0.0, QColor(34, 40, 64, 232))
        fill.setColorAt(0.55, QColor(19, 23, 42, 240))
        fill.setColorAt(1.0, QColor(10, 12, 24, 250))
        p.fillPath(glass, QBrush(fill))

        p.save()
        p.setClipPath(glass)

        # 顶部高光
        sheen = QLinearGradient(rect.topLeft(), QPointF(rect.left(), rect.top() + 90))
        sheen.setColorAt(0.0, QColor(255, 255, 255, 46))
        sheen.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.fillRect(QRectF(rect.left(), rect.top(), rect.width(), 90), QBrush(sheen))

        # 科技点阵
        step = 22.0
        off = int(getattr(self._win, "phase", 0.0) * 22) % 22
        p.setPen(QPen(QColor(110, 170, 255, 16), 1))
        x = rect.left() + 14 + (off % step)
        while x < rect.right() - 10:
            y = rect.top() + 56
            while y < rect.bottom() - 10:
                p.drawPoint(QPointF(x, y))
                y += step
            x += step

        # 扫描线
        span = max(1.0, rect.height() - 70)
        pos = rect.top() + 50 + (getattr(self._win, "phase", 0.0) * 60) % span
        sline = QLinearGradient(0, pos - 46, 0, pos + 46)
        sline.setColorAt(0.0, QColor(88, 210, 255, 0))
        sline.setColorAt(0.5, QColor(88, 210, 255, 26))
        sline.setColorAt(1.0, QColor(88, 210, 255, 0))
        p.fillRect(QRectF(rect.left() + 10, pos - 46, rect.width() - 20, 92), QBrush(sline))

        p.restore()

        # 全屏(圆角归零)时不画外发光
        if radius >= 2.0:
            for spread, alpha in ((7, 24), (3, 38)):
                gp = QPainterPath()
                gp.addRoundedRect(rect.adjusted(-spread, -spread, spread, spread),
                                  radius + spread, radius + spread)
                p.setPen(QPen(QColor(88, 190, 255, alpha), 1.2))
                p.setBrush(Qt.NoBrush)
                p.drawPath(gp)

        # 渐变主描边
        border = QLinearGradient(rect.topLeft(), rect.bottomRight())
        border.setColorAt(0.0, QColor(120, 220, 255, 230))
        border.setColorAt(0.45, QColor(130, 120, 255, 190))
        border.setColorAt(1.0, QColor(255, 105, 205, 150))
        p.setPen(QPen(QBrush(border), 1.6))
        p.setBrush(Qt.NoBrush)
        p.drawPath(glass)


# ---------------------------------------------------------------- 主窗口
class FloatWindow(QWidget):
    def __init__(self, default_fullscreen=True):
        super().__init__(None)
        self._drag_offset = None
        self._phase = 0.0
        self._fullscreen = False
        self._corner_radius = 22.0
        self._first_show = True
        self._default_fullscreen = default_fullscreen
        self._target_pos = (0, 0)
        self._fade_slide = False

        self.setWindowTitle("悬浮窗")
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self._panel = GlassPanel(self)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(self._panel)

        # 淡入特效
        # 淡入特效 (fade 时按需创建, 结束后移除保证文字清晰)
        self._fx = None

        self._setup_tray()

        # 动画计时器 (约 30fps 相位)
        self._timer = QTimer(self)
        self._timer.setInterval(30)
        self._timer.timeout.connect(self._tick)
        self._timer.start()

        self._fade_anim = None
        self._geo_anim = None
        self._proc = None

        QApplication.primaryScreen().availableGeometryChanged.connect(self._on_screen_changed)

    # ---- 相位 ----
    @property
    def phase(self):
        return self._phase

    def _tick(self):
        self._phase += 0.03
        self._panel.update()

    # ---- 托盘 ----
    def _setup_tray(self):
        try:
            self._tray = QSystemTrayIcon(self._make_icon(), self)
            self._tray.setToolTip("悬浮窗")
            menu = QMenu()
            act_show = QAction("显示", self)
            act_show.triggered.connect(self.show_animated)
            act_full = QAction("放大/缩小", self)
            act_full.triggered.connect(self.toggle_fullscreen)
            act_quit = QAction("退出", self)
            act_quit.triggered.connect(self.quit)
            menu.addAction(act_show)
            menu.addAction(act_full)
            menu.addSeparator()
            menu.addAction(act_quit)
            self._tray.setContextMenu(menu)
            self._tray.activated.connect(self._on_tray_activated)
            self._tray.show()
        except Exception:
            self._tray = None

    def _make_icon(self):
        pm = QPixmap(64, 64)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        grad = QLinearGradient(0, 0, 64, 64)
        grad.setColorAt(0.0, C_ACCENT_A)
        grad.setColorAt(1.0, C_ACCENT_B)
        p.setBrush(QBrush(grad))
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(QRectF(4, 4, 56, 56), 16, 16)
        p.setPen(QPen(QColor(255, 255, 255, 220), 5))
        p.drawEllipse(QPointF(32, 32), 12, 12)
        p.end()
        return QIcon(pm)

    def _on_tray_activated(self, reason):
        if reason in (QSystemTrayIcon.Trigger, QSystemTrayIcon.DoubleClick):
            self.show_animated()

    # ---- 屏幕 / 几何 ----
    def _current_screen(self):
        wh = self.windowHandle()
        if wh and wh.screen():
            return wh.screen()
        return QApplication.primaryScreen()

    def _screen_metrics(self):
        return self._current_screen().availableGeometry()

    def _full_screen_geo(self):
        return self._current_screen().geometry()

    def _compute_size(self, geo):
        w = max(320, min(460, int(geo.width() * 0.30)))
        h = max(440, min(720, int(geo.height() * 0.78)))
        ms = self.minimumSizeHint()
        w = max(w, ms.width())
        h = max(h, ms.height())
        return w, h

    def _normal_geometry(self):
        geo = self._screen_metrics()
        w, h = self._compute_size(geo)
        x = geo.right() - w - 24
        y = geo.top() + 24
        return QRect(x, y, w, h)

    def move_clamped(self, pos):
        geo = self._screen_metrics()
        x = max(geo.left(), min(pos.x(), geo.right() - self.width()))
        y = max(geo.top(), min(pos.y(), geo.bottom() - self.height()))
        self.move(x, y)

    def _on_screen_changed(self, geo):
        if self.isVisible():
            if self._fullscreen:
                self.setGeometry(self._full_screen_geo())
            else:
                self.move_clamped(self.pos())

    # ---- 显示 / 淡入 ----
    def show_animated(self):
        if self._first_show:
            self._first_show = False
            if self._default_fullscreen:
                self._fullscreen = True

        if self._fullscreen:
            self._corner_radius = 0.0
            self.setGeometry(self._full_screen_geo())
            self.show()
            self._run_fade_in(slide=False)
        else:
            self._corner_radius = 22.0
            geo = self._normal_geometry()
            self.setGeometry(geo)
            self._target_pos = (geo.x(), geo.y())
            self.move(geo.x(), geo.y() + 18)
            self.show()
            self._run_fade_in(slide=True)

        self._update_full_button()
        self._panel.update()

    def _run_fade_in(self, slide):
        self._fade_slide = slide
        fx = QGraphicsOpacityEffect()
        self._panel.setGraphicsEffect(fx)
        fx.setOpacity(0.0)
        self._fx = fx
        anim = QVariantAnimation(self)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setDuration(420)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.valueChanged.connect(self._on_fade)
        anim.finished.connect(self._on_fade_done)
        self._fade_anim = anim
        anim.start()

    def _on_fade_done(self):
        self._panel.setGraphicsEffect(None)
        self._fx = None

    def _on_fade(self, v):
        v = float(v)
        self._fx.setOpacity(v)
        if self._fade_slide:
            x, y = self._target_pos
            self.move(x, y + int((1.0 - v) * 18))

    # ---- 全屏切换 ----
    def toggle_fullscreen(self):
        if self._fullscreen:
            self._exit_fullscreen()
        else:
            self._enter_fullscreen()

    def _enter_fullscreen(self):
        self._fullscreen = True
        end = self._full_screen_geo()
        self._animate_geo(self.geometry(), end, self._corner_radius, 0.0)
        self._update_full_button()

    def _exit_fullscreen(self):
        self._fullscreen = False
        end = self._normal_geometry()
        self._animate_geo(self.geometry(), end, self._corner_radius, 22.0)
        self._update_full_button()

    def _animate_geo(self, start, end, r0, r1):
        anim = QVariantAnimation(self)
        anim.setDuration(320)
        anim.setEasingCurve(QEasingCurve.InOutCubic)

        def on_val(v):
            self._corner_radius = r0 + (r1 - r0) * v
            x = round(start.x() + (end.x() - start.x()) * v)
            y = round(start.y() + (end.y() - start.y()) * v)
            w = round(start.width() + (end.width() - start.width()) * v)
            h = round(start.height() + (end.height() - start.height()) * v)
            self.setGeometry(x, y, w, h)
            self._panel.update()

        anim.valueChanged.connect(on_val)
        anim.finished.connect(self._on_geo_done)
        self._geo_anim = anim
        anim.start()

    def _on_geo_done(self):
        if self._fullscreen:
            self.setGeometry(self._full_screen_geo())
            self._corner_radius = 0.0
        else:
            self.setGeometry(self._normal_geometry())
            self._corner_radius = 22.0
        self._panel.update()

    def _update_full_button(self):
        if hasattr(self._panel, "btn_full"):
            self._panel.btn_full.setText("缩小" if self._fullscreen else "放大")

    # ---- 托盘 / 退出 ----
    def hide_to_tray(self):
        self.hide()
        if self._tray:
            self._tray.showMessage("悬浮窗", "已最小化到托盘, 点击托盘图标恢复",
                                   QSystemTrayIcon.Information, 1500)

    def quit(self):
        if self._tray:
            self._tray.hide()
        QApplication.instance().quit()

    # ---- 安装执行 ----
    def run_install(self, prompt_filename):
        base = os.path.dirname(os.path.abspath(__file__))
        install_ps1 = os.path.join(base, "install.ps1")
        prompt_path = os.path.join(base, prompt_filename)

        if not os.path.exists(prompt_path):
            self._set_status("找不到文件: %s" % prompt_filename)
            return
        if not os.path.exists(install_ps1):
            self._set_status("找不到 install.ps1")
            return

        self._set_status("正在执行 %s …" % prompt_filename)
        self._set_buttons_enabled(False)

        if self._proc is not None and self._proc.state() != QProcess.NotRunning:
            self._proc.kill()
            self._proc.waitForFinished(2000)

        proc = QProcess(self)
        self._proc = proc
        proc.setWorkingDirectory(base)
        proc.setProcessChannelMode(QProcess.MergedChannels)
        proc.finished.connect(lambda code, st: self._on_install_done(prompt_filename, code, st))
        # 直接调用 install.ps1 (等价于点我执行.cmd 内部执行的 powershell 命令),
        # 避免 cmd.exe 对中文路径的编码问题
        proc.start("powershell.exe", [
            "-NoProfile", "-ExecutionPolicy", "RemoteSigned",
            "-File", install_ps1,
            "-SourcePrompt", prompt_path
        ])

    def _on_install_done(self, prompt_filename, exit_code, exit_status):
        self._set_buttons_enabled(True)
        ok = (exit_status == QProcess.NormalExit and exit_code == 0)
        if ok:
            self._set_status("✓ %s 已安装 · 重启 Codex 生效" % prompt_filename)
        else:
            self._set_status("✗ %s 执行失败 (退出码 %s)" % (prompt_filename, exit_code))

    def _set_buttons_enabled(self, enabled):
        body = getattr(self._panel, "body", None)
        if body:
            for name in ("btn_codex", "btn_flash", "btn_restart"):
                b = getattr(body, name, None)
                if b:
                    b.setEnabled(enabled)

    def _set_status(self, text):
        body = getattr(self._panel, "body", None)
        if body and hasattr(body, "status"):
            body.status.setText(text)

    def restart_codex(self):
        self._set_status("正在重启 Codex …")
        self._set_buttons_enabled(False)
        self._restart_log = os.path.join(
            os.environ.get("TEMP") or os.environ.get("TMP") or ".", "codex_restart.log")
        log = self._restart_log
        try:
            if os.path.exists(log):
                os.remove(log)
        except Exception:
            pass
        ps = (
            "$ErrorActionPreference='SilentlyContinue'; "
            "$lines=@(); "
            "$appId=(Get-StartApps | Where-Object { $_.AppID -like 'OpenAI.Codex*' } | "
            "Select-Object -First 1 -ExpandProperty AppID); "
            "$lines += ('appId=' + $appId); "
            "$chat=@(Get-Process ChatGPT | Where-Object { $_.Path -like '*OpenAI.Codex*' }); "
            "$lines += ('chatgpt_killed=' + $chat.Count); "
            "$chat | Stop-Process -Force; "
            "$cx=@(Get-Process codex -ErrorAction SilentlyContinue); "
            "$lines += ('codex_killed=' + $cx.Count); "
            "$cx | Stop-Process -Force; "
            "Start-Sleep -Milliseconds 1200; "
            "if ($appId) { "
            "  $p=Start-Process explorer.exe -ArgumentList ('shell:AppsFolder\\' + $appId) -PassThru; "
            "  $lines += ('relaunch=' + [bool]$p) "
            "} else { $lines += 'relaunch=NO_APPID' }; "
            "$lines -join ' | ' | Out-File -FilePath '" + log + "' -Encoding utf8"
        )
        subprocess.Popen(
            ["powershell.exe", "-NoProfile", "-Command", ps],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        QTimer.singleShot(4000, lambda: self._read_restart_log(0))

    def _read_restart_log(self, tries):
        log = getattr(self, "_restart_log", "")
        txt = ""
        if log and os.path.exists(log):
            try:
                txt = open(log, encoding="utf-8", errors="ignore").read().strip()
            except Exception:
                txt = ""
        if txt:
            self._set_status("重启: " + txt)
            self._set_buttons_enabled(True)
        elif tries < 2:
            QTimer.singleShot(3000, lambda: self._read_restart_log(tries + 1))
        else:
            self._set_status("重启已触发 · 请观察 Codex 是否重新打开")
            self._set_buttons_enabled(True)

    def show_tutorial(self):
        tut = getattr(self, "_tutorial", None)
        if tut is None:
            tut = TutorialWindow()
            self._tutorial = tut
        tut.show_animated()



# ---------------------------------------------------------------- 玻璃卡片
class GlassCard(QWidget):
    """圆角毛玻璃卡片 (带霓虹描边)"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TranslucentBackground)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        rect = QRectF(self.rect())
        radius = 22.0
        glass = QPainterPath()
        glass.addRoundedRect(rect, radius, radius)

        fill = QLinearGradient(rect.topLeft(), rect.bottomLeft())
        fill.setColorAt(0.0, QColor(30, 36, 58, 238))
        fill.setColorAt(0.55, QColor(17, 21, 38, 244))
        fill.setColorAt(1.0, QColor(9, 11, 22, 252))
        p.fillPath(glass, QBrush(fill))

        p.save()
        p.setClipPath(glass)
        sheen = QLinearGradient(rect.topLeft(), QPointF(rect.left(), rect.top() + 90))
        sheen.setColorAt(0.0, QColor(255, 255, 255, 40))
        sheen.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.fillRect(QRectF(rect.left(), rect.top(), rect.width(), 90), QBrush(sheen))
        p.restore()

        for spread, alpha in ((7, 24), (3, 38)):
            gp = QPainterPath()
            gp.addRoundedRect(rect.adjusted(-spread, -spread, spread, spread),
                              radius + spread, radius + spread)
            p.setPen(QPen(QColor(88, 190, 255, alpha), 1.2))
            p.setBrush(Qt.NoBrush)
            p.drawPath(gp)

        border = QLinearGradient(rect.topLeft(), rect.bottomRight())
        border.setColorAt(0.0, QColor(120, 220, 255, 230))
        border.setColorAt(0.45, QColor(130, 120, 255, 190))
        border.setColorAt(1.0, QColor(255, 105, 205, 150))
        p.setPen(QPen(QBrush(border), 1.6))
        p.setBrush(Qt.NoBrush)
        p.drawPath(glass)


# ---------------------------------------------------------------- 全屏暗色背景
class _Backdrop(QWidget):
    """同意弹窗的全屏科技背景"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TranslucentBackground)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        rect = QRectF(self.rect())
        fill = QLinearGradient(rect.topLeft(), rect.bottomLeft())
        fill.setColorAt(0.0, QColor(10, 12, 24, 235))
        fill.setColorAt(1.0, QColor(4, 5, 12, 245))
        p.fillRect(rect, QBrush(fill))

        phase = float(getattr(self.window(), "phase", 0.0))
        step = 26.0
        off = int(phase * 26) % 26
        p.setPen(QPen(QColor(110, 170, 255, 14), 1))
        x = rect.left() + 20 + (off % step)
        while x < rect.right():
            y = rect.top() + 20
            while y < rect.bottom():
                p.drawPoint(QPointF(x, y))
                y += step
            x += step

        span = max(1.0, rect.height())
        pos = (phase * 80) % span
        sline = QLinearGradient(0, pos - 60, 0, pos + 60)
        sline.setColorAt(0.0, QColor(88, 210, 255, 0))
        sline.setColorAt(0.5, QColor(88, 210, 255, 18))
        sline.setColorAt(1.0, QColor(88, 210, 255, 0))
        p.fillRect(QRectF(rect.left(), pos - 60, rect.width(), 120), QBrush(sline))


# ---------------------------------------------------------------- 同意弹窗
class AgreementWindow(QWidget):
    """进入时弹出的激活/免责声明窗: 点同意后消失并进入主悬浮窗"""
    agreed = Signal()

    def __init__(self):
        super().__init__(None)
        self._phase = 0.0
        self._agreeing = False
        self._fade_anim = None
        self._fade_out = None

        self.setWindowTitle("免责声明")
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setGeometry(QApplication.primaryScreen().geometry())

        self._backdrop = _Backdrop(self)
        rl = QVBoxLayout(self)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.addWidget(self._backdrop)

        self.card = GlassCard(self._backdrop)
        bl = QVBoxLayout(self._backdrop)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.addStretch(1)
        bl.addWidget(self.card, 0, Qt.AlignCenter)
        bl.addStretch(1)

        self._build_card_content()

        self._fx = None

        self._timer = QTimer(self)
        self._timer.setInterval(30)
        self._timer.timeout.connect(self._tick)
        self._timer.start()

        self._update_card_size()

    @property
    def phase(self):
        return self._phase

    def _tick(self):
        self._phase += 0.03
        self._backdrop.update()

    def _build_card_content(self):
        lay = QVBoxLayout(self.card)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(14)

        header = QLabel(ACTIVATION_LINE, self.card)
        header.setAlignment(Qt.AlignCenter)
        header.setWordWrap(True)
        header.setStyleSheet(
            "color:#6fe0ff; font-family:'%s'; font-size:19px; font-weight:700;" % FONT_UI)
        lay.addWidget(header)

        div = QFrame(self.card)
        div.setFixedHeight(1)
        div.setStyleSheet("background:rgba(130,150,200,60);")
        lay.addWidget(div)

        title = QLabel(DISCLAIMER_TITLE, self.card)
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet(
            "color:#eef2ff; font-family:'%s'; font-size:17px; font-weight:600;" % FONT_UI)
        lay.addWidget(title)

        scroll = QScrollArea(self.card)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet(
            "QScrollArea{background:rgba(10,14,26,120); border:1px solid rgba(130,150,200,40); border-radius:12px;}"
            "QScrollBar:vertical{background:transparent; width:8px; margin:2px;}"
            "QScrollBar::handle:vertical{background:rgba(120,170,255,70); border-radius:4px; min-height:30px;}"
            "QScrollBar::handle:vertical:hover{background:rgba(120,170,255,120);}"
            "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical{height:0;}"
            "QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical{background:transparent;}")
        body = QLabel(DISCLAIMER_TEXT, self.card)
        body.setWordWrap(True)
        body.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        body.setTextInteractionFlags(Qt.TextSelectableByMouse)
        body.setStyleSheet(
            "color:#c7d0e6; font-family:'%s'; font-size:14px; background:transparent; padding:6px;" % FONT_UI)
        scroll.setWidget(body)
        lay.addWidget(scroll, 1)

        btn = QPushButton(AGREE_TEXT, self.card)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setFixedHeight(44)
        btn.setStyleSheet(
            "QPushButton{color:#041018;"
            " background:qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #58d2ff, stop:0.5 #8278ff, stop:1 #ff69cd);"
            " border:none; border-radius:15px;"
            " font-family:'%s'; font-size:15px; font-weight:700; padding:0 24px;}"
            "QPushButton:hover{background:qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #7fddff, stop:0.5 #a293ff, stop:1 #ff8bd6);}"
            "QPushButton:pressed{background:qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #3fb8e0, stop:0.5 #6659e0, stop:1 #e04ba8);}" % FONT_UI)
        btn.clicked.connect(self._agree)
        lay.addWidget(btn)

        self.btn_agree = btn

    def _update_card_size(self):
        w = min(680, max(430, self.width() - 80))
        h = min(780, max(500, self.height() - 80))
        self.card.setFixedSize(w, h)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if hasattr(self, "card"):
            self._update_card_size()

    def show_animated(self):
        self.show()
        fx = QGraphicsOpacityEffect()
        self._backdrop.setGraphicsEffect(fx)
        fx.setOpacity(0.0)
        self._fx = fx
        anim = QVariantAnimation(self)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setDuration(360)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.valueChanged.connect(lambda v: self._fx.setOpacity(float(v)))
        anim.finished.connect(self._on_fade_in_done)
        self._fade_anim = anim
        anim.start()

    def _on_fade_in_done(self):
        self._backdrop.setGraphicsEffect(None)
        self._fx = None

    def _agree(self):
        if self._agreeing:
            return
        self._agreeing = True
        fx = QGraphicsOpacityEffect()
        self._backdrop.setGraphicsEffect(fx)
        fx.setOpacity(1.0)
        self._fx = fx
        anim = QVariantAnimation(self)
        anim.setStartValue(1.0)
        anim.setEndValue(0.0)
        anim.setDuration(260)
        anim.setEasingCurve(QEasingCurve.InCubic)
        anim.valueChanged.connect(lambda v: self._fx.setOpacity(float(v)))
        anim.finished.connect(self._on_agree_done)
        self._fade_out = anim
        anim.start()

    def _on_agree_done(self):
        self.agreed.emit()
        self.close()


# ---------------------------------------------------------------- 教程弹窗背景
class _CloseBackdrop(_Backdrop):
    """点空白处关闭的教程背景"""
    def mousePressEvent(self, e):
        self.window().close()
        super().mousePressEvent(e)


# ---------------------------------------------------------------- 使用教程弹窗
class TutorialWindow(QWidget):
    """使用教程弹窗: 点空白处退出"""
    def __init__(self):
        super().__init__(None)
        self._phase = 0.0
        self._fade_anim = None
        self.setWindowTitle("使用教程")
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setGeometry(QApplication.primaryScreen().geometry())

        self._backdrop = _CloseBackdrop(self)
        rl = QVBoxLayout(self)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.addWidget(self._backdrop)

        self.card = GlassCard(self._backdrop)
        bl = QVBoxLayout(self._backdrop)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.addStretch(1)
        bl.addWidget(self.card, 0, Qt.AlignCenter)
        bl.addStretch(1)

        self._build_content()

        self._timer = QTimer(self)
        self._timer.setInterval(30)
        self._timer.timeout.connect(self._tick)
        self._timer.start()

        self._update_card_size()

    @property
    def phase(self):
        return self._phase

    def _tick(self):
        self._phase += 0.03
        self._backdrop.update()

    def _build_content(self):
        lay = QVBoxLayout(self.card)
        lay.setContentsMargins(30, 26, 30, 26)
        lay.setSpacing(14)

        title = QLabel(TUTORIAL_TITLE, self.card)
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet(
            "color:#6fe0ff; font-family:'%s'; font-size:20px; font-weight:700;" % FONT_UI)
        lay.addWidget(title)

        div = QFrame(self.card)
        div.setFixedHeight(1)
        div.setStyleSheet("background:rgba(130,150,200,60);")
        lay.addWidget(div)

        scroll = QScrollArea(self.card)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet(
            "QScrollArea{background:rgba(10,14,26,120); border:1px solid rgba(130,150,200,40); border-radius:12px;}"
            "QScrollBar:vertical{background:transparent; width:8px; margin:2px;}"
            "QScrollBar::handle:vertical{background:rgba(120,170,255,70); border-radius:4px; min-height:30px;}"
            "QScrollBar::handle:vertical:hover{background:rgba(120,170,255,120);}"
            "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical{height:0;}"
            "QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical{background:transparent;}")
        body = QLabel(TUTORIAL_TEXT, self.card)
        body.setWordWrap(True)
        body.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        body.setTextInteractionFlags(Qt.TextSelectableByMouse)
        body.setStyleSheet(
            "color:#c9d3ea; font-family:'%s'; font-size:15px; background:transparent; padding:8px;" % FONT_UI)
        scroll.setWidget(body)
        lay.addWidget(scroll, 1)

        tip = QLabel("点空白处即可退出", self.card)
        tip.setAlignment(Qt.AlignCenter)
        tip.setStyleSheet(
            "color:rgba(150,160,190,150); font-family:'%s'; font-size:12px;" % FONT_UI)
        lay.addWidget(tip)

    def _update_card_size(self):
        w = min(680, max(460, self.width() - 100))
        h = min(720, max(500, self.height() - 80))
        self.card.setFixedSize(w, h)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if hasattr(self, "card"):
            self._update_card_size()

    def show_animated(self):
        self.show()
        fx = QGraphicsOpacityEffect()
        self._backdrop.setGraphicsEffect(fx)
        fx.setOpacity(0.0)
        self._fx = fx
        anim = QVariantAnimation(self)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setDuration(300)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.valueChanged.connect(lambda v: self._fx.setOpacity(float(v)))
        anim.finished.connect(self._on_fade_in_done)
        self._fade_anim = anim
        anim.start()

    def _on_fade_in_done(self):
        self._backdrop.setGraphicsEffect(None)
        self._fx = None


# ---------------------------------------------------------------- 入口
def main():
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)

    if "--selftest" in sys.argv:
        return selftest(app)

    # 单实例: 若已在运行(例如按钮触发 .cmd 又拉起新实例), 直接退出
    _singleton = QLocalServer()
    _probe = QLocalSocket()
    _probe.connectToServer("fj_float_window_v1")
    if _probe.waitForConnected(150):
        _probe.disconnectFromServer()
        return 0
    _singleton.removeServer("fj_float_window_v1")
    _singleton.listen("fj_float_window_v1")
    app._singleton = _singleton

    default_fullscreen = ("--windowed" not in sys.argv)
    smoke = ("--smoke" in sys.argv)

    agree = AgreementWindow()

    def on_agreed():
        agree.close()
        win = FloatWindow(default_fullscreen=default_fullscreen)
        win.show_animated()
        if smoke:
            QTimer.singleShot(800, app.quit)

    agree.agreed.connect(on_agreed)
    agree.show_animated()

    if smoke:
        QTimer.singleShot(900, agree._agree)

    sys.exit(app.exec())


def _render_to(win, path, bg_top=(36, 40, 56), bg_bottom=(16, 18, 30)):
    fx = getattr(win, "_fx", None)
    if fx is not None:
        fx.setOpacity(1.0)
    win.update()
    app_process()
    pix = win.grab()
    out = QImage(pix.size(), QImage.Format_RGB32)
    p = QPainter(out)
    bg = QLinearGradient(0, 0, 0, pix.height())
    bg.setColorAt(0.0, QColor(*bg_top))
    bg.setColorAt(1.0, QColor(*bg_bottom))
    p.fillRect(out.rect(), QBrush(bg))
    p.drawPixmap(0, 0, pix)
    p.end()
    out.save(path)
    return out


def app_process(n=2):
    for _ in range(n):
        QApplication.processEvents()


def selftest(app):
    here = os.path.dirname(os.path.abspath(__file__))

    # 1) 小悬浮窗
    win = FloatWindow(default_fullscreen=False)
    win._corner_radius = 22.0
    win._phase = 0.6
    win.setGeometry(QRect(0, 0, 420, 620))
    win.show()
    _render_to(win, os.path.join(here, "preview.png"))

    # 2) 全屏模式
    win._fullscreen = True
    win._corner_radius = 0.0
    win._update_full_button()
    win.setGeometry(QRect(0, 0, 1280, 720))
    _render_to(win, os.path.join(here, "preview_fullscreen.png"))
    win.hide()

    # 3) 同意弹窗
    agree = AgreementWindow()
    agree._phase = 0.6
    agree.setGeometry(QRect(0, 0, 1280, 720))
    agree._update_card_size()
    agree.show()
    _render_to(agree, os.path.join(here, "preview_agree.png"))

    print("OK saved preview.png / preview_fullscreen.png / preview_agree.png")
    return 0


if __name__ == "__main__":
    sys.exit(main())
